/* Puente Android: descargas y "Enviar reporte" nativos (solo actúa dentro del APK) */
(function(){
  var C = window.Capacitor;
  if(!C || !C.isNativePlatform || !C.isNativePlatform()) return;
  var FS = C.Plugins.Filesystem, SH = C.Plugins.Share;
  if(!FS || !SH) return;
  async function guardarYCompartir(text, name, title, msg){
    var r = await FS.writeFile({ path: name, data: text, directory: "CACHE", encoding: "utf8" });
    await SH.share({ title: title||name, text: msg||"", files: [r.uri], dialogTitle: title||"Compartir" });
  }
  window.dl = function(text, name, type){
    guardarYCompartir(text, name, name).catch(function(e){
      if(e && /cancel/i.test(String(e.message||e))) return;
      alert("No se pudo guardar el archivo: " + (e && e.message || e));
    });
  };
  window.enviarReporte = async function(all){
    var r = armarReporte(all);
    if(!r){ alert("No hay ventas nuevas para enviar."); return; }
    var d = new Date(), pad = function(n){ return String(n).padStart(2,"0"); };
    var name = "reporte_"+(S.settings.origen||"comite").replace(/[^\w-]+/g,"_")+"_"+d.getFullYear()+pad(d.getMonth()+1)+pad(d.getDate())+"_"+pad(d.getHours())+pad(d.getMinutes())+".json";
    try{
      await guardarYCompartir(JSON.stringify(r.rep), name, "Reporte de ventas", r.resumen);
    }catch(e){
      if(e && /cancel/i.test(String(e.message||e))) return;
      copiarReporte(all); return;
    }
    r.ventas.forEach(function(v){ v.sent = true; }); save(); renderLog();
  };
})();
